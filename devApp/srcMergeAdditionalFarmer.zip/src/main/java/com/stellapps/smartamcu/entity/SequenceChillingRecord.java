package com.stellapps.smartamcu.entity;

/**
 * Created by Upendra on 11/16/2015.
 */
public class SequenceChillingRecord extends CenterRecordEntity {


    private int seqNum;

    public SequenceChillingRecord() {

    }

    public int getSeqNum() {
        return seqNum;
    }

    public void setSeqNum(int seqNum) {
        this.seqNum = seqNum;
    }

}
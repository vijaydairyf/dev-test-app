package com.stellapps.smartamcu.postentities;

/**
 * Created by u_pendra on 18/1/18.
 */

public class TankerMetadata {

    public String number;
    public String routeNumber;
    public String supervisorCode;
}

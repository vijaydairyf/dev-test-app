package com.stellapps.smartamcu.httptasks;

import android.content.Context;

import com.stellapps.smartamcu.dao.CollectionRecordDao;
import com.stellapps.smartamcu.dao.DaoFactory;
import com.stellapps.smartamcu.entity.ReportEntity;
import com.stellapps.smartamcu.postentities.CollectionConstants;
import com.stellapps.smartamcu.server.DatabaseHandler;

import java.util.ArrayList;

/**
 * Created by Upendra on 8/19/2015.
 */
public class SMSHandler {

    public final static boolean SMS_SENT = true;
    public final static boolean SMS_UNSENT = false;
    private static Context mContext;
    private static SMSHandler smsHandler;
    int unsentMessageCount;

    public static SMSHandler getInstance(Context ctx) {
        mContext = ctx;
        if (smsHandler == null) {
            smsHandler = new SMSHandler();
        }
        return smsHandler;
    }

    private SMSHandler SMSHandler() {

        return smsHandler;
    }

    public ArrayList<ReportEntity> getNWUnsentSMS() {
        DatabaseHandler dbHandler = DatabaseHandler.getDatabaseInstance();
        CollectionRecordDao collectionRecordDao = (CollectionRecordDao) DaoFactory.getDao(CollectionConstants.REPORT_TYPE_COLLECTION);
        ArrayList<ReportEntity> reportEntities = new ArrayList<>();
        reportEntities = collectionRecordDao.findByUnsentSms();
        return reportEntities;

    }


    public void setSMSStatus(int sentStatus, int sequenceNumber) {
        CollectionRecordDao collectionRecordDao = (CollectionRecordDao) DaoFactory.getDao(CollectionConstants.REPORT_TYPE_COLLECTION);
        collectionRecordDao.updateSmsStatus(sequenceNumber, sentStatus);

    }

}

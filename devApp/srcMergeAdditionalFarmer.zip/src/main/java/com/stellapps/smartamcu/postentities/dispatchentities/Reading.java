/*package com.stellapps.smartamcu.postentities.dispatchentities;

 *//**
 * Created by shishir on 11/9/18.
 *//*

public class Reading {
    public double fat;
    public double snf;
}*/

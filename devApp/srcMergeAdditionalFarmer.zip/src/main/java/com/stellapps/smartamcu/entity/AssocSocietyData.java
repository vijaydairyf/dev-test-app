package com.stellapps.smartamcu.entity;

import java.io.Serializable;

public class AssocSocietyData implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public String socId;
    public String assocId;
    public String assoSocName;

}

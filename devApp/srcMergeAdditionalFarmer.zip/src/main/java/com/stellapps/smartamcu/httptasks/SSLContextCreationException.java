package com.stellapps.smartamcu.httptasks;

/**
 * Created by adukuri on 15/4/15.
 */
public class SSLContextCreationException extends Exception {
    public SSLContextCreationException(String message) {
        super(message);
    }
}
package com.stellapps.smartamcu.databaseTasks;

import android.content.ContentValues;

import java.util.ArrayList;

/**
 * Created by u_pendra on 2/2/18.
 */

public class ActionEntity {


    public String tableName;
    public ArrayList<ContentValues> contentValuesList;
    public String query;
    public String action;
    public int type;
}

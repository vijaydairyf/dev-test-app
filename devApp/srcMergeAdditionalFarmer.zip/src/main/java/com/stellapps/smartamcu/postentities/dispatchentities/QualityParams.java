/*package com.stellapps.smartamcu.postentities.dispatchentities;

 *//**
 * Created by shishir on 9/9/18.
 *//*

public class QualityParams {
    public String mode;
    public MilkAnalyzer milkAnalyzer;
}*/

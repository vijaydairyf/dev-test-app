package com.stellapps.smartamcu.helper;

/**
 * Created by u_pendra on 29/12/16.
 */

public enum BarcodePrefix {

    STPL,
    SIN
}

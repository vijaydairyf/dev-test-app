package com.stellapps.smartamcu.license.deviceInfo;

import java.io.Serializable;

/**
 * Created by nitin on 24/6/16.
 */
public class DeviceInfoEntity implements Serializable {
    public BuildInfo buildInfosList;
    public KernalInfo kernalInfoList;
    public TelephoneInfo telephoneInfoList;
}

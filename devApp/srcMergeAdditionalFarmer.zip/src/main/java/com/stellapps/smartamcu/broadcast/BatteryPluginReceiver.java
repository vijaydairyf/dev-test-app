package com.stellapps.smartamcu.broadcast;

/**
 * Created by u_pendra on 6/5/17.
 */

public class BatteryPluginReceiver {
}

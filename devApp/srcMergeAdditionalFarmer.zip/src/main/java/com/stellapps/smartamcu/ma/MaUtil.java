package com.stellapps.smartamcu.ma;

/**
 * Created by harshith on 5/1/18.
 */

public class MaUtil {
    /*public static final String "LACTOSCAN")) {
        isLactoScan = true;
    } else if (ma.equalsIgnoreCase("EKOMILK ULTRA PRO")) {
        isEKOMilkUltra = true;
    } else if (ma.equalsIgnoreCase("EKOMILK")) {
        isEKOMILK = true;

    } else if (ma.equalsIgnoreCase("LM2") || ma.equalsIgnoreCase("LACTOPLUS")) {
        isLM2 = true;
    } else if (ma.equalsIgnoreCase("KAMDHENU")) {
        isKamDhenu = true;
    } else if (ma.equalsIgnoreCase("AKASHGANGA") && (MAbaudRate == 9600)) {
        isAkashGanga = true;
    } else if (ma.equalsIgnoreCase("AKASHGANGA") && (MAbaudRate == 2400)) {
        isEKOMilkUltra = true;
    } else if (ma.equalsIgnoreCase("INDIFOSS")) {
        isIndifoss = true;
    } else if (ma.equalsIgnoreCase("NULINE")
            || ma.equalsIgnoreCase("EKOBOND")) {
        isNuline = true;
    } else if (ma.equalsIgnoreCase("LACTOSCAN_V2")) {
        isLactoScanV2 = true;
    } else if (ma.equalsIgnoreCase("KSHEERAA")) {
        isKsheeraa = true;
    } else if (ma.equalsIgnoreCase("EKOMILK EVEN")) {
        isEkoMilkEven = true;
    } else if (ma.equalsIgnoreCase("EKOMILK_V2")) {
        isEkomilkV2 = true;
    } else if (ma.equalsIgnoreCase("LAKTAN_240")) {
        isLaktan240 = true;
        SLEEP_TIME = 100;
    }*/
}

package com.stellapps.smartamcu.ma;

import android.view.View;

import com.stellapps.smartamcu.entity.MilkAnalyserEntity;

/**
 * Interface for uSB connection and receive data
 */

public interface MaManager {
    void startReading();

    void writeToMA(String msg);

    void stopReading();

    void displayAlert(View.OnClickListener onClickListener, boolean mandatory);

    void setOnNewDataListener(OnNewDataListener listener);

    void resetConnection(int delay);

    interface OnNewDataListener {
        void onNewData(MilkAnalyserEntity maEntity);

        void onOtherMessage(String message);
    }
}

package com.stellapps.smartamcu.entity;

/**
 * Created by Upendra on 4/22/2016.
 */
public class SequenceUpdatedRecords extends UpdatedRecordEntity {


    private int seqNum;

    public SequenceUpdatedRecords() {

    }

    public int getSeqNum() {
        return seqNum;
    }

    public void setSeqNum(int seqNum) {
        this.seqNum = seqNum;
    }


}

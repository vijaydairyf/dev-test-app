package com.stellapps.smartamcu.helper;

/**
 * Created by u_pendra on 18/4/17.
 */

public class CattleType {

    public static final String COW = "COW";
    public static final String BUFFALO = "BUFFALO";
    public static final String MIXED = "MIXED";
    public static final String TEST = "TEST";

    public static final String MERGED_HMB = "MERGED HMB";
    public static final String BOTH = "BOTH";
    public static final String GOAT = "GOAT";

    public static final String NA = "NA";
}

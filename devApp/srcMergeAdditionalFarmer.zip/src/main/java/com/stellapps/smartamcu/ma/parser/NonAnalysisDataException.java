package com.stellapps.smartamcu.ma.parser;

/**
 * Created by harshith on 8/1/18.
 */

public class NonAnalysisDataException extends Exception {
    public NonAnalysisDataException(String s) {
        super(s);
    }
}

package com.stellapps.smartamcu.entity;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by u_pendra on 6/2/18.
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface TransactionalEntity {


}

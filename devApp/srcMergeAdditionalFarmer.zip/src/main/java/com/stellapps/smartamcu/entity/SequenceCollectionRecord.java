package com.stellapps.smartamcu.entity;

/**
 * Created by venkat on 25/5/15.
 */
public class SequenceCollectionRecord extends CollectionEntry {

    private int seqNum;

    public SequenceCollectionRecord() {

    }

    public int getSeqNum() {
        return seqNum;
    }

    public void setSeqNum(int seqNum) {
        this.seqNum = seqNum;
    }
}

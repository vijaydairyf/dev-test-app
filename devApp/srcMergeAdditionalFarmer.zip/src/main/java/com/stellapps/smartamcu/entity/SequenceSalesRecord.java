package com.stellapps.smartamcu.entity;

/**
 * Created by Upendra on 11/16/2015.
 */
public class SequenceSalesRecord extends SalesEntry {


    private int seqNum;

    public SequenceSalesRecord() {

    }

    public int getSeqNum() {
        return seqNum;
    }

    public void setSeqNum(int seqNum) {
        this.seqNum = seqNum;
    }

}

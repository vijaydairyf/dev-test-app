package com.stellapps.smartamcu.postentities;

/**
 * Created by u_pendra on 18/1/18.
 */

public class FarmerSplitId {

    public String aggregateFarmerId;
    public String producerId;
    public String userId;
}

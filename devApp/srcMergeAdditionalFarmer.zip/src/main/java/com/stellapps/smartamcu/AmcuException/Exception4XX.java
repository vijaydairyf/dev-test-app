package com.stellapps.smartamcu.AmcuException;

/**
 * Created by u_pendra on 22/1/18.
 */

public class Exception4XX extends Exception {

    public Exception4XX(String exception) {
        super(exception);
    }

}

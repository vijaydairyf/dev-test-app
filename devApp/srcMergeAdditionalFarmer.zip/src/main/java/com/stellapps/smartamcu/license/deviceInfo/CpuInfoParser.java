package com.stellapps.smartamcu.license.deviceInfo;

/**
 * Created by nitin on 23/6/16.
 */
public class CpuInfoParser {
}

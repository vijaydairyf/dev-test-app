package com.stellapps.smartamcu.peripherals.interfaces;

import com.stellapps.smartamcu.peripherals.devices.DeviceParameters;
import com.stellapps.smartamcu.usb.DeviceEntity;

/**
 * Created by shishir on 24/1/18.
 */

public interface Device {
    void read();

    void unregisterObserver();

    void closeConnection();

    void write(String msg);

    void write(byte[] msg);

    void writeAsync(byte[] msg);

    void setParameters(DeviceParameters parameters);

    void registerObserver(DataObserver dataObserver);

    void registerListener(WriteDataListener dataListener);

    DeviceEntity getDeviceEntity();

    DeviceParameters getDeviceParams();

    interface ErrorListener {
        void onError(Exception e, DeviceEntity deviceEntity);

        void onError(String errorMessage, DeviceEntity deviceEntity);
    }
}

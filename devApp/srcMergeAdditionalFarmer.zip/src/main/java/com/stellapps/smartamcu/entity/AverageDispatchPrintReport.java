package com.stellapps.smartamcu.entity;

/**
 * Created by shishir on 17/9/18.
 */

public class AverageDispatchPrintReport {

    public double totalCollection;
    public double totalAmount;
}

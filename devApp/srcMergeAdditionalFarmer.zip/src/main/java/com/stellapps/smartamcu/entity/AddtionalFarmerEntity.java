package com.stellapps.smartamcu.entity;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

import java.io.Serializable;

/**
 * Created by mahendran on 22/10/18.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddtionalFarmerEntity implements Serializable {
    @JsonProperty("cowHerdSize")
    public String cowHerdSize;
    @JsonProperty("buffaloHerdSize")
    public String buffaloHerdSize;
    @JsonProperty("numberOfFamily")
    public String numberOfFamily;
    @JsonProperty("region")
    public String region;
    @JsonProperty("dairyIncome")
    public String dairyIncome;
    @JsonProperty("primarySource")
    public String primarySource;
    @JsonProperty("age")
    public String age;
    @JsonProperty("education")
    public String education;
    @JsonProperty("pincode")
    public String pincode;
    @JsonProperty("address")
    public String address;
    @JsonProperty("ecsCode")
    public String ecsCode;

}

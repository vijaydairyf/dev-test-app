package com.stellapps.smartamcu.helper;

/**
 * Created by u_pendra on 29/12/16.
 */

public class UserType {

    public final static String FARMER = "farmer";
    public final static String CENTER = "center";
    public final static String SAMPLE = "smaple";
    public final static String RATE_CHECK = "ratecheck";
    public final static String INVALID = "invalid";

    public final static String SUPPORT_USERID = "1234";
    public final static String SUPPORT_PASSWORD = "1234";
    public final static String AMCU = "AMCU";

}

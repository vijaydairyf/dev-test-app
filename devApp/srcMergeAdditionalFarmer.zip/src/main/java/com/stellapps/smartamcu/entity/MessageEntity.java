package com.stellapps.smartamcu.entity;

import java.io.Serializable;

public class MessageEntity implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public String socId;
    public String msgCount;
    public String msgLimit;
    public String date;

}

package com.stellapps.smartamcu.services;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;

import com.stellapps.smartamcu.entity.DeviceId;
import com.stellapps.smartamcu.json.JSONParser;
import com.stellapps.smartamcu.server.AmcuConfig;
import com.stellapps.smartamcu.server.ServerResponse;
import com.stellapps.smartamcu.user.Util;

public class PostServiceEndSession extends IntentService {

    ServerResponse response;
    AmcuConfig amcuConfig;
    DeviceId deviceId;
    String server;

    public PostServiceEndSession() {
        super("PostService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        String url = null;
        amcuConfig = AmcuConfig.getInstance();
        server = amcuConfig.getURLHeader() + amcuConfig.getServer();
        getDeviceID();

        if (amcuConfig.getPostData() == 1) {
            url = server + "/amcu/collectionentries";
            response = JSONParser.postData(url, Util.poEndShift, 1);
        } else if (amcuConfig.getPostData() == 2) {
            url = server + "/smartamcu/farmercollectionentry";
            response = JSONParser.postData(url, Util.poPerFarmer, 2);
        }
    }

    public void getDeviceID() {
        TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

        String device_id = tm.getDeviceId();
        deviceId = new DeviceId();
        deviceId.imeiNumber = device_id;

    }

}

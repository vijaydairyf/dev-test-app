package com.stellapps.smartamcu.agentfarmersplit;

import java.io.Serializable;

/**
 * Created by u_pendra on 31/7/17.
 */

public class ShiftConcluded implements Serializable {

    public String date;
    public String shift;
}

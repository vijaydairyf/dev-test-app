package com.stellapps.smartamcu.entity;

import java.io.Serializable;

public class RateUpload implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public double fat;
    public double snf;
    public double rate;

}

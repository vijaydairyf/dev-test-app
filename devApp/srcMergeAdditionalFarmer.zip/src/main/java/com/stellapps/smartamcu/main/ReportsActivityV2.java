package com.stellapps.smartamcu.main;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.stellapps.usb.R;

public class ReportsActivityV2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports_v2);
    }
}

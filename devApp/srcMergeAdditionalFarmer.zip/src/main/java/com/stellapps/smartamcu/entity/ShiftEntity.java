package com.stellapps.smartamcu.entity;

/**
 * Created by u_pendra on 23/12/16.
 */

public class ShiftEntity {

    public long morningStartTime;
    public long morningEndTime;
    public long eveningStartTime;
    public long eveningEndTime;
    public long morningCollectionStartTime;
    public long morningCollectionEndTime;
    public long eveningCollectionStartTime;
    public long eveningCollectionEndtime;
}

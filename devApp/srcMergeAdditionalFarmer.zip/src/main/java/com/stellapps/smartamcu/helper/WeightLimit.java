package com.stellapps.smartamcu.helper;

/**
 * Created by u_pendra on 20/2/17.
 */

public interface WeightLimit {

    boolean exceedWeightLimit();

    boolean proceedWithExceedWeightLimit();

}

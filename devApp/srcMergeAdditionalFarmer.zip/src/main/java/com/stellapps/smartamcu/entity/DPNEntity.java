package com.stellapps.smartamcu.entity;

import java.io.Serializable;

/**
 * Created by u_pendra on 13/6/17.
 */

public class DPNEntity implements Serializable {

    public long id;
    public String url;
    public String dpnType;
    public String dpnStatus;
    public long generatedTime;

}

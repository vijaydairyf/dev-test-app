package com.stellapps.smartamcu.entity;

import java.io.Serializable;

public class UpdateRatechartEntity implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public int status;
    public String imeiNumber;

}

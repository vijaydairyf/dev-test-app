package com.stellapps.smartamcu.postentities;

/**
 * Created by u_pendra on 17/1/18.
 */

public class RateParamsPost {

    public String unit;
    public String mode;
    public String rateChartName;
    public boolean isRateCalculated;
    public double rate;
    public double incentive;
    public double bonus;
    public double amountToBePaid;
    public double incentiveRate;
}

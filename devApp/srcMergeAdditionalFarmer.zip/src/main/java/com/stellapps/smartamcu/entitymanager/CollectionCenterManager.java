package com.stellapps.smartamcu.entitymanager;

import android.content.Context;

import com.stellapps.smartamcu.agentfarmersplit.AppConstants;
import com.stellapps.smartamcu.dao.CollectionCenterDao;
import com.stellapps.smartamcu.dao.Dao;
import com.stellapps.smartamcu.dao.DaoFactory;
import com.stellapps.smartamcu.entity.CenterEntity;
import com.stellapps.smartamcu.entity.CenterPostEntity;
import com.stellapps.smartamcu.entity.Entity;
import com.stellapps.smartamcu.helper.CattleType;
import com.stellapps.smartamcu.network.EntityManager;
import com.stellapps.smartamcu.network.InvalidUpdateException;
import com.stellapps.smartamcu.postentities.CollectionConstants;
import com.stellapps.smartamcu.server.AmcuConfig;
import com.stellapps.smartamcu.server.SessionManager;
import com.stellapps.smartamcu.user.Util;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by harshith on 31/1/18.
 */

public class CollectionCenterManager implements EntityManager {

    private final String TYPE = AppConstants.ConfigurationTypes.COLLECTION_CENTER_LIST;
    private CollectionCenterDao dao;
    private AmcuConfig amcuConfig;
    private SessionManager sessionManager;
    private Context mContext;

    public CollectionCenterManager(Context context) {
        mContext = context;
        amcuConfig = AmcuConfig.getInstance();
        sessionManager = new SessionManager(mContext);
        dao = (CollectionCenterDao) DaoFactory.getDao(CollectionConstants.COLLECTION_CENTER);
    }

    @Override
    public List<Entity> getEntityFromJson(String jsonString, boolean isCloudPush) throws IOException, InvalidUpdateException {
        ObjectMapper mapper = new ObjectMapper();
        List<CenterPostEntity> centerList = mapper.readValue(jsonString, new TypeReference<List<CenterPostEntity>>() {
        });
        List<Entity> centerEntityList = new ArrayList<>();
        for (int i = 0, len = centerList.size(); i < len; i++) {
            CenterPostEntity cPE = centerList.get(i);
            if (cPE.producerProfile.milkType == null || cPE.producerProfile.milkType.equalsIgnoreCase("")) {
                cPE.producerProfile.milkType = CattleType.COW;
            }
            CenterEntity centerEntity = new CenterEntity(centerList.get(i));
            centerEntity.chillingCenterId = String.valueOf(sessionManager.getSocietyColumnId());

            centerEntityList.add(centerEntity);
        }
        return centerEntityList;
    }

    @Override
    public String getDpnUrl() {
        if (Util.CHILLING_CENTER_URI != null && Util.CHILLING_CENTER_URI.contains("amcu")) {
            amcuConfig.setChillingCenterUri(Util.CHILLING_CENTER_URI);
            Util.CHILLING_CENTER_URI = null;
        }
        if (amcuConfig.getChillingUri() != null) {
            return amcuConfig.getChillingUri();
        }
        return null;
    }

    @Override
    public void resetDpnUrl() {
        amcuConfig.setCenterFailCount(0);
        amcuConfig.setChillingCenterUri(null);
    }

    @Override
    public String getType() {
        return TYPE;
    }

    @Override
    public Dao getDao() {
        return dao;
    }

    @Override
    public void saveAll(List<? extends Entity> entityList, boolean isCloudPush) {
        for (int i = 0, len = entityList.size(); i < len; i++) {
            CenterEntity centerEntity = (CenterEntity) entityList.get(i);
            String msg = Util.getDuplicateIdOrBarCode(centerEntity.centerId, centerEntity.centerBarcode, mContext);
            if (msg != null && !msg.contains("Center")) {
                Util.displayErrorToast(msg, mContext);
                continue;
            }
            if (centerEntity.cattleType == null || centerEntity.cattleType.equalsIgnoreCase("")) {
                centerEntity.cattleType = CattleType.COW;
            }
            dao.saveOrUpdate(centerEntity);
        }
        Util.displayErrorToast("Collection Centers Updated Successfully", mContext);
    }
}

package com.stellapps.smartamcu.databaseTasks;

/**
 * Created by u_pendra on 22/1/18.
 */

public class DatabaseActions {


}

package com.stellapps.smartamcu.entity;

import java.io.Serializable;

public class DeviceId implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public String simMSISDN;
    public String imeiNumber;
    public String societyIdStr;

}

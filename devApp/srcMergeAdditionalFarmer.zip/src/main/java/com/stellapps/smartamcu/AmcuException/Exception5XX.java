package com.stellapps.smartamcu.AmcuException;

/**
 * Created by u_pendra on 22/1/18.
 */

public class Exception5XX extends Exception {

    public Exception5XX(String exception) {
        super(exception);
    }

}

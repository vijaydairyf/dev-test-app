package com.stellapps.smartamcu.entitymanager;

import android.content.Context;

import com.stellapps.smartamcu.agentfarmersplit.AppConstants;
import com.stellapps.smartamcu.dao.Dao;
import com.stellapps.smartamcu.dao.DaoFactory;
import com.stellapps.smartamcu.dao.TruckDao;
import com.stellapps.smartamcu.entity.Entity;
import com.stellapps.smartamcu.network.EntityManager;
import com.stellapps.smartamcu.network.InvalidUpdateException;
import com.stellapps.smartamcu.postentities.CollectionConstants;
import com.stellapps.smartamcu.server.AmcuConfig;
import com.stellapps.smartamcu.user.Util;
import com.stellapps.smartcc.entities.TrucKInfo;
import com.stellapps.smartcc.entityandconstants.SmartCCConstants;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

import java.io.IOException;
import java.util.List;

/**
 * Created by harshith on 1/2/18.
 */

public class TruckManager implements EntityManager {

    private final String TYPE = AppConstants.ConfigurationTypes.TRUCK;
    private TruckDao dao;
    private AmcuConfig amcuConfig;
    private Context mContext;

    public TruckManager(Context context) {
        mContext = context;
        amcuConfig = AmcuConfig.getInstance();
        dao = (TruckDao) DaoFactory.getDao(CollectionConstants.TRUCK);
    }

    @Override
    public List<Entity> getEntityFromJson(String jsonString, boolean isCloudPush) throws IOException, InvalidUpdateException {
        ObjectMapper mapper = new ObjectMapper();
        List<Entity> truckList = mapper.readValue(jsonString, new TypeReference<List<TrucKInfo>>() {
        });
        return truckList;
    }

    @Override
    public String getDpnUrl() {
        if (SmartCCConstants.TRUCK_UPDATE_URI != null) {
            amcuConfig.setTruckUpdateUrl(SmartCCConstants.TRUCK_UPDATE_URI);
            String test = amcuConfig.getTruckUpdateUrl();
            SmartCCConstants.TRUCK_UPDATE_URI = null;
        }
        if (amcuConfig.getTruckUpdateUrl() != null) {
            return amcuConfig.getTruckUpdateUrl();
        }
        return null;
    }

    @Override
    public void resetDpnUrl() {
        amcuConfig.setTruckFailCount(0);
        amcuConfig.setTruckUpdateUrl(null);
    }

    @Override
    public String getType() {
        return TYPE;
    }

    @Override
    public Dao getDao() {
        return dao;
    }

    @Override
    public void saveAll(List<? extends Entity> entityList, boolean isCloudPush) {
        for (int i = 0, len = entityList.size(); i < len; i++) {
            dao.saveOrUpdate(entityList.get(i));
        }
        Util.displayErrorToast("Truck(s) Updated Successfully", mContext);
    }
}

package com.stellapps.smartamcu.network;

import android.content.Context;

import com.stellapps.smartamcu.agentfarmersplit.AppConstants;
import com.stellapps.smartamcu.entitymanager.AgentManager;
import com.stellapps.smartamcu.entitymanager.CollectionCenterManager;
import com.stellapps.smartamcu.entitymanager.ConfigEntityManager;
import com.stellapps.smartamcu.entitymanager.FarmerManager;
import com.stellapps.smartamcu.entitymanager.IncentiveRateChartManager;
import com.stellapps.smartamcu.entitymanager.RateChartManager;
import com.stellapps.smartamcu.entitymanager.TruckManager;

/**
 * Created by harshith on 28/1/18.
 */

public class UpdateServiceFactory {

    private final Context mContext;

    public UpdateServiceFactory(Context context) {
        mContext = context;
    }

    public UpdateService getUpdateService(String configType) {
        UpdateService updateService = null;
        switch (configType) {
            case AppConstants.ConfigurationTypes.AGENT: {
                updateService = new UpdateService(mContext, new AgentManager(mContext));
                break;
            }

            case AppConstants.ConfigurationTypes.COLLECTION_CENTER_LIST: {
                updateService = new UpdateService(mContext, new CollectionCenterManager(mContext));
                break;
            }
            case AppConstants.ConfigurationTypes.CONFIGURATION: {
                updateService = new UpdateService(mContext, new ConfigEntityManager(mContext));
                break;
            }
            case AppConstants.ConfigurationTypes.FARMER: {
                updateService = new UpdateService(mContext, new FarmerManager(mContext));
                break;
            }
            case AppConstants.ConfigurationTypes.INCENTIVE_RATE_CHART: {
                updateService = new UpdateService(mContext, new IncentiveRateChartManager(mContext));
                break;
            }
            case AppConstants.ConfigurationTypes.RATE_CHART: {
                updateService = new UpdateService(mContext, new RateChartManager(mContext));
                break;
            }
            case AppConstants.ConfigurationTypes.TRUCK: {
                updateService = new UpdateService(mContext, new TruckManager(mContext));
                break;
            }
        }
        return updateService;
    }
}

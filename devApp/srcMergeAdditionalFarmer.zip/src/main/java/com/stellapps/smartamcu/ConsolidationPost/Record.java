package com.stellapps.smartamcu.ConsolidationPost;

/**
 * Created by u_pendra on 17/1/18.
 */

public abstract class Record {

}

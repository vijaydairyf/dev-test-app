package com.stellapps.smartamcu.entity;

/**
 * Created by harshith on 29/1/18.
 */

public class ConfigSyncStatusUpdateEntity {
    public String status;
    public String imeiNumber;
    public Long id;
}

package com.stellapps.smartamcu.services;

import android.app.IntentService;
import android.content.Intent;

import com.stellapps.smartamcu.entity.RateChartEntity;
import com.stellapps.smartamcu.server.DatabaseHandler;
import com.stellapps.smartamcu.user.Util;

import java.util.ArrayList;

public class EnterRCEntity extends IntentService {

    ArrayList<RateChartEntity> allRcEnt;

    public EnterRCEntity() {
        super("EnterRcEnt");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        allRcEnt = Util.ReadRateChartEntity(getApplicationContext(), 0);

        DatabaseHandler dbh = DatabaseHandler.getDatabaseInstance();

        try {
            dbh.insertValidationTableR(allRcEnt, DatabaseHandler.isPrimary);
            dbh.insertValidationTableR(allRcEnt, DatabaseHandler.isSecondary);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}

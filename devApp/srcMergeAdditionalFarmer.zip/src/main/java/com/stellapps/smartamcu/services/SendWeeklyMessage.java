package com.stellapps.smartamcu.services;

import android.app.IntentService;
import android.content.Intent;

public class SendWeeklyMessage extends IntentService {

    public SendWeeklyMessage() {
        super("SendWeek");
    }

    @Override
    protected void onHandleIntent(Intent arg0) {

    }

}

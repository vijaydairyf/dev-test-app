package com.stellapps.smartamcu.entity;

/**
 * Created by u_pendra on 5/2/18.
 */

public class EditRecordStatusEntity extends SalesRecordStatusEntity {
}

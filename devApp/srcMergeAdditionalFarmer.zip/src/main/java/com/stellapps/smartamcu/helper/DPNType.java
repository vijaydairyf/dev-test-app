package com.stellapps.smartamcu.helper;

/**
 * Created by u_pendra on 9/1/17.
 */

public class DPNType {

    public static final String RATECHART_DPN = "RATECHART";
    public static final String FARMER_DPN = "FARMER";
    public static final String MCC_DPN = "COLLECTION_CENTER";
    public static final String APK_DPN = "APK";
    public static final String AGENT_DPN = "AGENT";
    public static final String TRUCK_DPN = "TRUCK";
    public static final String CONFIG_DPN = "CONFIG";
    public static final String USER_DPN = "USER";


}

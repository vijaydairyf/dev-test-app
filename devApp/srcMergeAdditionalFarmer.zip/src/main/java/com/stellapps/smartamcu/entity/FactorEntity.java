package com.stellapps.smartamcu.entity;

import java.io.Serializable;

public class FactorEntity implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public String cattleType;
    public String socId;
    public String kgFactor;

}

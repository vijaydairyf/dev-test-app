package com.stellapps.smartamcu.postentities;

/**
 * Created by u_pendra on 17/1/18.
 */

public class ConsolidatedId {

    public String collectionCenter;
    public String route;
    public String chillingCenter;
    public String organization;
}

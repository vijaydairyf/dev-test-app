package com.stellapps.smartamcu.peripherals.controllers;

import java.net.Socket;

/**
 * Created by shishir on 26/6/18.
 */

public interface WisensController {
    Socket startConnection(String msg, String ip);

    void stopConnection();
}

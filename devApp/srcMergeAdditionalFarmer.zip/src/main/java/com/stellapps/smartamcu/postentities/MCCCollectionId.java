package com.stellapps.smartamcu.postentities;

/**
 * Created by u_pendra on 18/1/18.
 */

public class MCCCollectionId {

    public String agent;
    public String producer;
    public String user;
}

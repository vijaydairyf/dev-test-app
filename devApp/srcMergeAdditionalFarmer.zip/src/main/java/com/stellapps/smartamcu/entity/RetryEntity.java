package com.stellapps.smartamcu.entity;

import java.io.Serializable;

/**
 * Created by u_pendra on 7/12/16.
 */

public class RetryEntity implements Serializable {

    public int numberOfAttempts;
    public String fat;
    public String snf;
    public String quantity;
    public long collectionTime;


}

package com.stellapps.smartamcu.postentities.salesEntities;

/**
 * Created by shishir on 12/9/18.
 */

public class Id {
    public String aggregateFarmer;
    public String producer;
    public String user;
}

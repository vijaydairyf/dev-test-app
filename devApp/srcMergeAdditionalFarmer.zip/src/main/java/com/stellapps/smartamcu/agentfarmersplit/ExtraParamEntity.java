package com.stellapps.smartamcu.agentfarmersplit;

/**
 * Created by harshith on 26/7/17.
 */

public class ExtraParamEntity {
    public long columnId;
    public String key;
    public String value;
    public long refSeqNum;
    public long updatedTime;
    public int committed;
    public int sentStatus;
    public long collectionTime;
    public String farmerId;
    public String date;
    public String shift;
    public String milkType;
    public String collectionType;
    public long seqNum;

//    public String key;
//    public String extraParameters;
//    public long updatedTime;
//    public long collectionTime;
//    public String farmerId;
//    public String date;
//    public String shift;
//    public String milkType;
//    public long seqNum;
//    public long refSeqNum;

}

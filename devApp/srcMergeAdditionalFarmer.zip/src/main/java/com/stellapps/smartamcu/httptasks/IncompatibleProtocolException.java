package com.stellapps.smartamcu.httptasks;

/**
 * Created by adukuri on 14/4/15.
 */
public class IncompatibleProtocolException extends Exception {
    public IncompatibleProtocolException(String message) {
        super(message);
    }
}

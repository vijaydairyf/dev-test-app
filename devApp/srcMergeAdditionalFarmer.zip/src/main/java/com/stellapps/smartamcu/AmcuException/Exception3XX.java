package com.stellapps.smartamcu.AmcuException;

/**
 * Created by u_pendra on 22/1/18.
 */

public class Exception3XX extends Exception {

    public Exception3XX(String exception) {
        super(exception);
    }

}
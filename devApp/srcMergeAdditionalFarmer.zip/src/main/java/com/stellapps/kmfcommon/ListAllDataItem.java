package com.stellapps.kmfcommon;

/**
 * Created by nitin on 11/2/16.
 */
public class ListAllDataItem {
    public String truckNumber;
    public String quantity;
    public String issueDate;
    public String amount;
    public String purity;
    public String milkType;
    public String avgFat;
    public String avgSnf;
    public String rate;
    public String shift;

    public String getPurity() {
        return purity;
    }

    public void setPurity(String purity) {
        this.purity = purity;
    }

    public String getMilkType() {
        return milkType;
    }

    public void setMilkType(String milkType) {
        this.milkType = milkType;
    }

    public String getAvgFat() {
        return avgFat;
    }

    public void setAvgFat(String avgFat) {
        this.avgFat = avgFat;
    }

    public String getAvgSnf() {
        return avgSnf;
    }

    public void setAvgSnf(String avgSnf) {
        this.avgSnf = avgSnf;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

    public String getTruckNumber() {
        return truckNumber;
    }

    public void setTruckNumber(String truckNumber) {
        this.truckNumber = truckNumber;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }


}

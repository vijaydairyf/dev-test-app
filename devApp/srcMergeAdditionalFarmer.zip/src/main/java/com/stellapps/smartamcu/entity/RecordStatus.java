package com.stellapps.smartamcu.entity;

/**
 * Created by u_pendra on 12/4/17.
 */

public class RecordStatus {

    public final static String ACCEPT = "Accept";
    public final static String REJECT = "Reject";
    public final static String FAILURE = "Failure";
    public final static String SUCCESS = "Success";

    public final static String AUTO = "Auto";
    public final static String MANUAL = "Manual";

}

package com.stellapps.smartamcu.postentities;

/**
 * Created by u_pendra on 18/1/18.
 */

public class CanInOut {

    public int in;
    public int out;
}

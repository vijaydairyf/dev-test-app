package com.stellapps.smartamcu.entity;

/**
 * Created by u_pendra on 9/2/17.
 */

public final class SupportedMilkAnalyzer {

    String AKASHGANGA = "AKASHGANGA";
    String EKOMILK = "EKOMILK";
    String EKOMILK_ULTRA_PRO = "EKOMILK ULTRA PRO";
    String NULINE = "NULINE";
    String INDIFOSS = "INDIFOSS";
    String LACTOSCAN = "LACTOSCAN";
    String LM2 = "LM2";
    String KAMDHENU = "KAMDHENU";
    String EKOBOND = "EKOBOND";
    String LACTOSCANV2 = "LACTOSCAN_V2";
    String KSHEERAA = "KSHEERAA";
    String EKOMILK_EVEN = "EKOMILK EVEN";
    String EKOMILK_V2 = "EKOMILK_V2";
    String LAKTAN_240 = "LAKTAN_240";

}

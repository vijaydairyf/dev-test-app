package com.stellapps.smartamcu.peripherals.interfaces;

/**
 * Created by shishir on 2/2/18.
 */

public interface DataObserver {

    void onDataReceived(byte[] data);
}

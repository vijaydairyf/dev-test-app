package com.stellapps.smartamcu.postentities;

/**
 * Created by u_pendra on 17/1/18.
 */

public class FarmerCollectionId {

    public String aggregateFarmer;
    public String producer;
    public String user;
}

package com.stellapps.smartamcu.entity;

/**
 * Created by Upendra on 11/16/2015.
 */
public class SalesEntry {


    public String salesId;
    public long salesTime;
    public String milkType;
    public double milkQuantity;
    public double fat;
    public double snf;
    public double clr;
    public double amount;
    public double rate;
    public double awm;
    public String status;
    public String quantity_mode;
    public String quality_mode;
    public double temperature;
    public String mode;
    public String txnType;
    public String txnSubType;
}

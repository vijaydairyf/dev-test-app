/*
package com.stellapps.smartamcu.postentities.dispatchentities;

*/
/**
 * Created by shishir on 9/9/18.
 *//*


public class MilkAnalyzer {
    public Reading reading;
}
*/

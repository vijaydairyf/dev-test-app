package com.stellapps.smartamcu.postentities.dispatchentities;

import com.stellapps.smartamcu.ConsolidationPost.CustomSerializable;
import com.stellapps.smartamcu.ConsolidationPost.SynchronizableElement;
import com.stellapps.smartamcu.entity.Entity;
import com.stellapps.smartamcu.postentities.QualityParamsPost;
import com.stellapps.smartamcu.postentities.QuantityParamspost;
import com.stellapps.smartamcu.server.DatabaseHandler;
import com.stellapps.smartamcu.tableEntities.DispatchCollectionTable;
import com.stellapps.smartamcu.tableEntities.FarmerCollectionTable;
import com.stellapps.smartcc.entityandconstants.SmartCCUtil;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by shishir on 9/9/18.
 */

public class DispatchPostEntity implements Serializable, Entity, SynchronizableElement {

    @JsonIgnore
    public long columnId;
    @JsonIgnore
    public int sentStatus;
    @JsonIgnore
    public long timeInMillis;
    @JsonIgnore
    public String date;
    @JsonIgnore
    public String time;
    @JsonIgnore
    public String shift;
    public String supervisorId;
    public int numberOfCans;
    public String milkType;
    @JsonSerialize(using = CustomSerializable.class)
    public Date collectionTime;
    public QuantityParamspost quantityParams;
    public QualityParamsPost qualityParams;
    public long sequenceNumber;
    public long lastModified;

    @Override
    public Object getPrimaryKeyId() {
        return columnId;
    }

    @Override
    public void setPrimaryKeyId(Object id) {
        this.columnId = (long) id;
    }

    @Override
    public long getColumnId() {
        return columnId;
    }

    @Override
    public void setSentStatus(int status) {
        String updateQuery = "update " + DispatchCollectionTable.TABLE_DISPATCH_REPORT
                + " set " + DispatchCollectionTable.KEY_SEND_STATUS + " = " + status
                + ", " + FarmerCollectionTable.LAST_MODIFIED + " = " + this.lastModified
                + " where " + DispatchCollectionTable.KEY_COLUMN_ID + " = " + this.getColumnId();
        DatabaseHandler.getPrimaryTask().doAction(updateQuery);
        return;
    }

    @Override
    public long calculateMin(long min) {
        if (SmartCCUtil.MIN_DATE == null || SmartCCUtil.MIN_DATE.getTime() > min) {
            SmartCCUtil.MIN_DATE = SmartCCUtil.getCollectionDateFromLongTime(min);
        }
        return 0;
    }

    @Override
    public long calculateMax(long max) {
        if (SmartCCUtil.MAX_DATE == null || SmartCCUtil.MAX_DATE.getTime() < max) {
            SmartCCUtil.MAX_DATE = SmartCCUtil.getCollectionDateFromLongTime(max);
        }
        return 0;
    }
}

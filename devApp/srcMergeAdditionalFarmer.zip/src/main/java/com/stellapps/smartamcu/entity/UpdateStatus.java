package com.stellapps.smartamcu.entity;

/**
 * Created by Upendra on 2/9/2016.
 */
public class UpdateStatus {


    public final static int FAILURE = 0;
    public final static int SUCCESS = 1;
    public final static int ACTIVATION_FAILURE = 2;
    public final static int ACTIVATION_SUCCESS = 3;
    public final static int INVALID_SOCIETY = 4;
    public final static int FAIL_TO_SAVE_DATA = 5;


}

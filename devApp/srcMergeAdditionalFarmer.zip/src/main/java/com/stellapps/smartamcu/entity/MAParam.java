package com.stellapps.smartamcu.entity;

import java.io.Serializable;

/**
 * Created by u_pendra on 10/4/17.
 */

public class MAParam implements Serializable {


    public boolean fat;
    public boolean snf;
    public boolean den;
    public boolean lac;
    public boolean sn;
    public boolean temp;
    public boolean ph;
    public boolean salt;
    public boolean pro;
    public boolean adw;
    public boolean frp;
    public boolean cal;
    public boolean com;
}

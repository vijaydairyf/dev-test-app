package com.stellapps.smartamcu.deviceinfo;

/**
 * Created by u_pendra on 22/12/17.
 */

public class GetDeviceStatusService {
}

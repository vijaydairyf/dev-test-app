package com.stellapps.smartamcu.entitymanager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.stellapps.smartamcu.httptasks.Task;
import com.stellapps.smartamcu.httptasks.TaskScheduler;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Task task = (Task) intent.getSerializableExtra(TaskScheduler.TASK_OBJECT);
        if (task != null && context != null) {
            Intent i = new Intent(context, task.getService());
            context.startService(i);
            //   Toast.makeText(context, "Invoking the service:" + task.getCode(), Toast.LENGTH_SHORT).show();
        }
    }
}

package com.stellapps.smartamcu.entity;

/**
 * Created by mahendran on 15/2/18.
 */

public class MCCCollectionId {
    public String agent;
    public String producer;
    public String userId;
}

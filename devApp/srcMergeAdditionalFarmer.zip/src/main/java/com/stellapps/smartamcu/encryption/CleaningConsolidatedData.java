package com.stellapps.smartamcu.encryption;

import com.stellapps.smartamcu.entity.essae.EssaeCleaningEntity;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by shishir on 22/3/18.
 */

public class CleaningConsolidatedData implements Serializable {


    public String csvVersion = "1.0";
    public ArrayList<EssaeCleaningEntity> records;

}

package com.stellapps.smartamcu.databaseTasks;

/**
 * Created by u_pendra on 1/2/18.
 */

public interface EntityType {


    int FARMER = 1;
    int CENTER = 2;
    int RATE_CHART = 3;


}

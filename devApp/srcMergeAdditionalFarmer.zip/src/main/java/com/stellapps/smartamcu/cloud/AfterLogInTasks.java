package com.stellapps.smartamcu.cloud;

import android.content.Context;
import android.content.Intent;

import com.stellapps.smartamcu.devicemanager.DatabaseManager;
import com.stellapps.smartamcu.httptasks.RateChartPullService;
import com.stellapps.smartamcu.server.AmcuConfig;
import com.stellapps.smartamcu.user.Util;

public class AfterLogInTasks {

    Context mContext;
    boolean isAuth;
    AmcuConfig amcuConfig;
    String server;


    public AfterLogInTasks(Context ctx, boolean isAuthenticated) {
        this.mContext = ctx;
        this.isAuth = isAuthenticated;
        amcuConfig = AmcuConfig.getInstance();
        server = amcuConfig.getURLHeader() + amcuConfig.getServer();


    }

    public void startTasks() {
        if (isAuth) {
                    /*
                    if (saveSession.getLogInFor() == Util.LOGINFORAPK) {
						APKManager apkManager = new APKManager(mContext);
						apkManager.getUpdatedApk();
					} else*/
            if (amcuConfig.getLogInFor() == Util.LOGINRATECHART) {
                Intent intent = new Intent(mContext, RateChartPullService.class);
                mContext.startService(intent);
            }

        } else {
            if (amcuConfig.getLogInFor() == Util.LOGINRATECHART) {

                DatabaseManager rateChartManager = new DatabaseManager(
                        mContext);
                rateChartManager.manageRateChart();

            } else if (amcuConfig.getLogInFor() == Util.LOGINFORAPK) {
                APKManager.apkDownloadInprogress = true;

            }
        }
    }
}

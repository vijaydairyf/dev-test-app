package com.stellapps.smartamcu.configSync;

/**
 * Created by u_pendra on 17/1/18.
 */

public class SyncRateChartRepo {
}

package com.stellapps.smartamcu.entity;

import java.io.Serializable;

public class EntityRateChart implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public String etBaseRate;
    public String etFatStart;
    public String etFatEnd;
    public String etSnfStart;
    public String etSnfEnd;
    public String etFatRateIn;
    public String etSnfRateIn;
    public String count;
    public String button = "Done";

}

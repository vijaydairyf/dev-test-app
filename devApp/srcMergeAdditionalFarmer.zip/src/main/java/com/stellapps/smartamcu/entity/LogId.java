package com.stellapps.smartamcu.entity;

import java.io.Serializable;

/**
 * Created by u_pendra on 7/8/18.
 */

public class LogId implements Serializable {

    public String collectionId;
    public String userId;
    public String deviceId;
}

package com.stellapps.smartamcu.ma.parser;

/**
 * Created by harshith on 20/1/18.
 */

public class DataFlushRequiredException extends Exception {
    public DataFlushRequiredException(String message) {
        super(message);
    }
}
